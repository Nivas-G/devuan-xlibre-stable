srcs_config = [
    'config.c',
]

config_dep = [common_dep]

if build_dbus
    srcs_config += 'dbus-core.c'
    config_dep += dbus_dep
endif

if build_hal
    srcs_config += 'hal.c'
    config_dep += hal_dep
endif

if build_udev
    srcs_config += 'udev.c'
    config_dep += udev_dep
endif

if host_machine.system() == 'netbsd' or host_machine.system() == 'openbsd'
    srcs_config += 'wscons.c'
endif

if build_xorg
    install_data('10-quirks.conf',
                 install_dir: join_paths(get_option('datadir'), 'X11/xorg.conf.d'))
    nvidia_conf = configuration_data()
    nvidia_conf.set('libdir', join_paths(get_option('prefix'),get_option('libdir')))
    configure_file(
        input: '10-nvidia.conf.in',
        output: '10-nvidia.conf',
        configuration: nvidia_conf,
        install_dir: join_paths(get_option('datadir'), 'X11/xorg.conf.d'),
    )
    configure_file(
        input: '10-nvidia-modules.conf.in',
        output: '10-nvidia-modules.conf',
        configuration: nvidia_conf,
        install_dir: join_paths(get_option('datadir'), 'X11/xorg.conf.d'),
    )
    configure_file(
        input: '10-nvidia.conf.debian.in',
        output: '10-nvidia.conf.debian',
        configuration: nvidia_conf,
        install_dir: join_paths(get_option('sysconfdir'), 'X11/xorg.conf.d'),
    )
    configure_file(
        input: '10-nvidia-modules.conf.debian.in',
        output: '10-nvidia-modules.conf.debian',
        configuration: nvidia_conf,
        install_dir: join_paths(get_option('sysconfdir'), 'X11/xorg.conf.d'),
    )
endif

libxserver_config = static_library('xserver_config',
    srcs_config,
    include_directories: inc,
    dependencies: config_dep,
)
